const express = require('express')
const http = require('http');
const app = express()
const port = 3001


app.get("/" , (req,res,next)=>{
  
})

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`)
})

